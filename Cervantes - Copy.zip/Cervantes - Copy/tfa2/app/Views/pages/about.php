<?= $this->include('layouts/header') ?>

<h1>About SimplePOS</h1>

<p>
    SimplePOS is a basic CodeIgniter 4 Point-of-Sale website.
    This version uses static PHP arrays as temporary data sources,
    so no database is used yet.
</p>

<?= $this->include('layouts/footer') ?>