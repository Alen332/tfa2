<?= $this->include('layouts/header') ?>

<h1>Welcome to SimplePOS</h1>

<p>
    This is a basic Point-of-Sale system prototype. Use the navigation menu
    to view customer accounts and user accounts.
</p>

<?= $this->include('layouts/footer') ?>